//
//  ViewController.swift
//  ScrollableExample
//
//  Created by ChikabuZ on 28.10.17.
//  Copyright © 2017 Cosmonia Inc. All rights reserved.
//

import UIKit

class ViewController: ViewControllerWithScrollViewAndKeyboard {

    @IBOutlet var continueButton: UIButton!
    
    override var bottomViewFrame: CGRect? {
        return continueButton.frame
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func textFieldDidEndEditing(_ textField: UITextField) {

        activeTextInputFrame = textField.frame
    }
    
    override func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

}
